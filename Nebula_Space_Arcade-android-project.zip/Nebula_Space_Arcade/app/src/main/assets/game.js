const canvas = document.getElementById('gameCanvas');
const ctx = canvas.getContext('2d');
const scoreEl = document.getElementById('score');
const livesEl = document.getElementById('lives');
const startOverlay = document.getElementById('start-overlay');
const btnStart = document.getElementById('btn-start');

let width, height;
function resize() {
  width = canvas.width = canvas.parentElement.clientWidth;
  height = canvas.height = canvas.parentElement.clientHeight;
}
window.addEventListener('resize', resize);
resize();

let score = 0;
let lives = 3;
let isPlaying = false;
let player = { x: 0, y: 0, w: 32, h: 32, speed: 6 };
let bullets = [];
let enemies = [];
let stars = [];
let leftPressed = false;
let rightPressed = false;

// Audio context for sound effects
let audioCtx = null;
function playLaserSound() {
  try {
    if (!audioCtx) audioCtx = new (window.AudioContext || window.webkitAudioContext)();
    const osc = audioCtx.createOscillator();
    const gain = audioCtx.createGain();
    osc.type = 'sawtooth';
    osc.frequency.setValueAtTime(600, audioCtx.currentTime);
    osc.frequency.exponentialRampToValueAtTime(120, audioCtx.currentTime + 0.12);
    gain.gain.setValueAtTime(0.15, audioCtx.currentTime);
    gain.gain.exponentialRampToValueAtTime(0.01, audioCtx.currentTime + 0.12);
    osc.connect(gain);
    gain.connect(audioCtx.destination);
    osc.start();
    osc.stop(audioCtx.currentTime + 0.12);
  } catch (_) {}
}

function initStars() {
  stars = [];
  for (let i = 0; i < 40; i++) {
    stars.push({
      x: Math.random() * width,
      y: Math.random() * height,
      r: Math.random() * 1.5 + 0.5,
      speed: Math.random() * 1.5 + 0.5
    });
  }
}

function resetGame() {
  score = 0;
  lives = 3;
  scoreEl.textContent = score;
  livesEl.textContent = '❤️❤️❤️';
  player.x = width / 2 - player.w / 2;
  player.y = height - 120;
  bullets = [];
  enemies = [];
  initStars();
  isPlaying = true;
  startOverlay.style.display = 'none';
}

function fireBullet() {
  if (!isPlaying) return;
  bullets.push({ x: player.x + player.w / 2 - 2, y: player.y, w: 4, h: 12, speed: 10 });
  playLaserSound();
  if (window.Android && window.Android.vibrate) {
    window.Android.vibrate(20);
  }
}

// Touch listeners
document.getElementById('btn-left').addEventListener('touchstart', (e) => { e.preventDefault(); leftPressed = true; });
document.getElementById('btn-left').addEventListener('touchend', (e) => { e.preventDefault(); leftPressed = false; });
document.getElementById('btn-right').addEventListener('touchstart', (e) => { e.preventDefault(); rightPressed = true; });
document.getElementById('btn-right').addEventListener('touchend', (e) => { e.preventDefault(); rightPressed = false; });
document.getElementById('btn-fire').addEventListener('touchstart', (e) => { e.preventDefault(); fireBullet(); });

// Mouse fallback for controls
document.getElementById('btn-left').addEventListener('mousedown', () => leftPressed = true);
document.getElementById('btn-left').addEventListener('mouseup', () => leftPressed = false);
document.getElementById('btn-right').addEventListener('mousedown', () => rightPressed = true);
document.getElementById('btn-right').addEventListener('mouseup', () => rightPressed = false);
document.getElementById('btn-fire').addEventListener('click', fireBullet);

window.addEventListener('keydown', (e) => {
  if (e.key === 'ArrowLeft') leftPressed = true;
  if (e.key === 'ArrowRight') rightPressed = true;
  if (e.key === ' ' || e.key === 'Enter') fireBullet();
});
window.addEventListener('keyup', (e) => {
  if (e.key === 'ArrowLeft') leftPressed = false;
  if (e.key === 'ArrowRight') rightPressed = false;
});

btnStart.addEventListener('click', () => {
  resetGame();
});

let lastSpawn = 0;
function update(delta) {
  if (!isPlaying) return;

  if (leftPressed && player.x > 10) player.x -= player.speed;
  if (rightPressed && player.x < width - player.w - 10) player.x += player.speed;

  // Stars
  stars.forEach(s => {
    s.y += s.speed;
    if (s.y > height) s.y = 0;
  });

  // Bullets
  for (let i = bullets.length - 1; i >= 0; i--) {
    bullets[i].y -= bullets[i].speed;
    if (bullets[i].y < -20) bullets.splice(i, 1);
  }

  // Spawn enemies
  if (Date.now() - lastSpawn > 1200) {
    enemies.push({
      x: Math.random() * (width - 40) + 10,
      y: -30,
      w: 28,
      h: 28,
      speed: Math.random() * 2 + 2
    });
    lastSpawn = Date.now();
  }

  // Enemies
  for (let i = enemies.length - 1; i >= 0; i--) {
    const e = enemies[i];
    e.y += e.speed;

    // Check hit by bullet
    for (let j = bullets.length - 1; j >= 0; j--) {
      const b = bullets[j];
      if (b.x < e.x + e.w && b.x + b.w > e.x && b.y < e.y + e.h && b.y + b.h > e.y) {
        enemies.splice(i, 1);
        bullets.splice(j, 1);
        score += 100;
        scoreEl.textContent = score;
        break;
      }
    }

    // Check hit bottom
    if (e.y > height - 100) {
      enemies.splice(i, 1);
      lives--;
      livesEl.textContent = '❤️'.repeat(Math.max(0, lives));
      if (window.Android && window.Android.vibrate) window.Android.vibrate(100);
      if (lives <= 0) {
        isPlaying = false;
        startOverlay.style.display = 'flex';
        startOverlay.querySelector('h1').textContent = 'GAME OVER';
        startOverlay.querySelector('p').textContent = 'Final Score: ' + score;
      }
    }
  }
}

function render() {
  ctx.fillStyle = '#0b0f19';
  ctx.fillRect(0, 0, width, height);

  // Draw Stars
  ctx.fillStyle = '#64748b';
  stars.forEach(s => {
    ctx.beginPath();
    ctx.arc(s.x, s.y, s.r, 0, Math.PI * 2);
    ctx.fill();
  });

  if (isPlaying) {
    // Player
    ctx.fillStyle = '#38bdf8';
    ctx.beginPath();
    ctx.moveTo(player.x + player.w / 2, player.y);
    ctx.lineTo(player.x + player.w, player.y + player.h);
    ctx.lineTo(player.x, player.y + player.h);
    ctx.closePath();
    ctx.fill();

    // Bullets
    ctx.fillStyle = '#a855f7';
    bullets.forEach(b => {
      ctx.fillRect(b.x, b.y, b.w, b.h);
    });

    // Enemies
    ctx.fillStyle = '#ef4444';
    enemies.forEach(e => {
      ctx.fillRect(e.x, e.y, e.w, e.h);
    });
  }

  requestAnimationFrame(() => {
    update();
    render();
  });
}

initStars();
render();
